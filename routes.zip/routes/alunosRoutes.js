const express = require('express');
const router = express.Router();

const alunos = require('../controllers/alunosController');

router.get('/', alunos.listarAlunos);

router.get('/:id', alunos.buscarAluno);

router.post('/', alunos.cadastrarAluno);

router.put('/:id', alunos.atualizarAluno);

router.delete('/:id', alunos.removerAluno);

module.exports = router;