const express = require('express');
const router = express.Router();

const cursos = require('../controllers/cursosController');

router.get('/', cursos.listarCursos);

router.get('/:id', cursos.buscarCurso);

router.post('/', cursos.cadastrarCurso);

router.delete('/:id', cursos.removerCurso);

module.exports = router;