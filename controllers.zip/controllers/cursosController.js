const connection = require('../database/connection');

exports.listarCursos = (req,res)=>{
    connection.query(
        'SELECT * FROM cursos',
        (erro,resultado)=>{
            if(erro){
                return res.status(500).json({erro:'Erro no banco'});
            }

            res.json(resultado);
        }
    );
};

exports.buscarCurso = (req,res)=>{
    const { id } = req.params;

    connection.query(
        'SELECT * FROM cursos WHERE id=?',
        [id],
        (erro,resultado)=>{
            if(erro){
                return res.status(500).json({erro:'Erro no banco'});
            }

            res.json(resultado);
        }
    );
};

exports.cadastrarCurso = (req,res)=>{
    const {nome,carga_horaria,aluno_id} = req.body;

    connection.query(
        'INSERT INTO cursos(nome,carga_horaria,aluno_id) VALUES(?,?,?)',
        [nome,carga_horaria,aluno_id],
        (erro)=>{
            if(erro){
                return res.status(500).json({erro:'Erro ao cadastrar'});
            }

            res.json({
                mensagem:'Curso cadastrado'
            });
        }
    );
};

exports.removerCurso = (req,res)=>{
    const { id } = req.params;

    connection.query(
        'DELETE FROM cursos WHERE id=?',
        [id],
        (erro)=>{
            if(erro){
                return res.status(500).json({erro:'Erro ao remover'});
            }

            res.json({
                mensagem:'Curso removido'
            });
        }
    );
};