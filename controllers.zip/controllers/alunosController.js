const express = require('express');
const connection = require('../database/connection');

exports.listarAlunos = (req,res)=>{
    connection.query(
        'SELECT * FROM alunos',
        (erro,resultado)=>{
            if(erro){
                return res.status(500).json({erro:'Erro no banco'});
            }

            res.json(resultado);
        }
    );
};

exports.buscarAluno = (req,res)=>{
    const { id } = req.params;

    connection.query(
        'SELECT * FROM alunos WHERE id=?',
        [id],
        (erro,resultado)=>{
            if(erro){
                return res.status(500).json({erro:'Erro no banco'});
            }

            res.json(resultado);
        }
    );
};

exports.cadastrarAluno = (req,res)=>{
    const {nome, email, telefone, data_cadastro} = req.body;

    connection.query(
        'INSERT INTO alunos(nome, email, telefone, data_cadastro) VALUES(?,?,?,?)',
        [nome, email, telefone, data_cadastro],
        (erro)=>{
            if(erro){
                return res.status(500).json({erro:'Erro ao cadastrar'});
            }

            res.json({
                mensagem:'Aluno cadastrado com sucesso'
            });
        }
    );
};

exports.atualizarAluno = (req,res)=>{
    const { id } = req.params;
    const {nome, email, telefone, data_cadastro} = req.body;

    connection.query(
        'UPDATE alunos SET nome=?, email=?, telefone=?, data_cadastro=? WHERE id=?',
        [nome, email, telefone, data_cadastro,id],
        (erro)=>{
            if(erro){
                return res.status(500).json({erro:'Erro ao atualizar'});
            }

            res.json({
                mensagem:'Aluno atualizado'
            });
        }
    );
};

exports.removerAluno = (req,res)=>{
    const { id } = req.params;

    connection.query(
        'DELETE FROM alunos WHERE id=?',
        [id],
        (erro)=>{
            if(erro){
                return res.status(500).json({erro:'Erro ao remover'});
            }

            res.json({
                mensagem:'Aluno removido'
            });
        }
    );
};