require('dotenv').config();

const express = require('express');

const alunosRoutes = require('./src/routes/alunosRoutes');
const cursosRoutes = require('./src/routes/cursosRoutes');

const app = express();

app.use(express.json());

app.use('/alunos', alunosRoutes);
app.use('/cursos', cursosRoutes);


app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});